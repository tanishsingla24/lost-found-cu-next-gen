// assets/js.js
// reserved for future enhancements (notifications, client-side validation).
// currently we use small inline scripts in pages for simplicity.
